import { Input } from 'antd';
import React, { FC, memo } from 'react';
import { AdvancedSearch} from 'xdad';

const FormProps:FC = () => {
  return (
    <AdvancedSearch>
      <Input />
    </AdvancedSearch>
  );
};


export default memo(FormProps);
