import { DatePicker, Input, Select } from 'antd';
import React from 'react';
import { AdvancedSearch } from 'xdad';


const Index = () => {
  const { QuickFrom, AdvancedForm } = AdvancedSearch;

  return (
    <>
      <AdvancedSearch
        onKeyEnter={(a, b, c, d) => {
          console.log(a, b, c, d);
        }}
        onSearch={(a, b, c) => {
          console.log(a, b, c);
        }}
      >
        {/* <QuickFrom> */}
        <Input data-name="testa" data-simple data-itemprops={{
          name: '345',
          rules: [{ required: true, message: '222' }]
        }} />
        <Select data-name="testr" data-simple />
        <Select data-name="testy" data-simple />
        {/* </QuickFrom>
        <AdvancedForm initialValues={{ name: '1234' }}> */}
        <Input data-name="name" placeholder='请输入姓名' />
        <Input data-name="test2" data-itemprops={{
          rules: [{ required: true, message: '222' }]
        }} />
        <Select data-name="test3" />
        <DatePicker data-name="test4" style={{ width: '100%' }} />
        <Select data-name="test5" />
        <DatePicker data-name="test6" style={{ width: '100%' }} />
        {/* </AdvancedForm> */}
      </AdvancedSearch>
    </>
  );
};

export default Index;
