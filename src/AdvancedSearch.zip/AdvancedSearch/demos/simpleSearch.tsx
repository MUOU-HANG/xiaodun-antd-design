import { Input } from 'antd';
import React, { FC, memo } from 'react';
import { AdvancedSearch} from 'xdad';

const SimpleSearch:FC = () => {
  return (
    <AdvancedSearch
      onSearch={(value) => {
        console.log(value);
      }} >
      <Input placeholder="快捷搜索示例" data-simple data-name="simple" />
    </AdvancedSearch>
  );
};


export default memo(SimpleSearch);
