import InternalAdvancedSearch, { reset } from './advancedSearch';
import QuickFrom from './quickForm';
import AdvancedForm from './advancedForm';

type InternalAdvancedSearchType = typeof InternalAdvancedSearch;

interface AdvancedSearchInterface extends InternalAdvancedSearchType{
  reset: typeof reset;
  QuickFrom: typeof QuickFrom,
  AdvancedForm: typeof AdvancedForm,

}

const AdvancedSearch = InternalAdvancedSearch as AdvancedSearchInterface;

AdvancedSearch.reset = reset;
AdvancedSearch.QuickFrom = QuickFrom;
AdvancedSearch.AdvancedForm = AdvancedForm;

export default AdvancedSearch;
