declare namespace React {

  interface HTMLProps<T> extends IntrinsicAttributes ,IntrinsicClassAttributes , Pick {
  }
}
