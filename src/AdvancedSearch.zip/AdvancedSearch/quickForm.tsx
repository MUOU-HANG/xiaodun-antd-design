import React from 'react';


const QuickFrom = () => {

  return (<span></span>);
};


export default QuickFrom;
