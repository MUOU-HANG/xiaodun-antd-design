import { Button, Form } from 'antd';
import React, { FC } from 'react';


export interface AdvancedFormProps {
  form: any,
  children:any,
  onInternalSearch:(values:object)=> void
}

const AdvancedForm: FC<AdvancedFormProps> = ({ children, form,onInternalSearch,...rest }) => {
  console.log(rest,'rest');

  const advancedFormRender = (
    children instanceof Array && children.map((child, index) => {
      const type: any = child.type;
      const name = child.props['data-name'];
      const itemprops = child.props['data-itemprops'];
      const isSelect = typeof type === 'object' && type?.render?.name === 'InternalSelect';
      const width = typeof child.props['data-width'] === 'number' ? `${child.props['data-width']} px` : child.props['data-width'];

      return (
        <Form.Item
          key={name ?? index}
          name={name}
          {...itemprops}
          style={{ width: width ? width : (isSelect ? '160px' : '240px') }}
          className="xdad-advance-form-item"
        >
          {child}
        </Form.Item>
      );
    })
  );
  return (
    <Form
      className="xdad-advance-form"
      form={form}
      layout="inline"
      {...rest}
    >
      {advancedFormRender}
      <span className="xdad-advance-form-btns">
        <Button onClick={onInternalSearch}>查询</Button>
        <Button id="xdad-advanced-reset" style={{ marginLeft: 10 }} onClick={() => form.resetFields()}>重置</Button>
      </span>
    </Form>
  );
};


export default AdvancedForm;
